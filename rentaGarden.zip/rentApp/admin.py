from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Region),
admin.site.register(Ciudad),
admin.site.register(Comuna),
admin.site.register(Admin),
admin.site.register(Arrendatario),
admin.site.register(Caracteristica),
admin.site.register(Planta),
admin.site.register(Pedido),
admin.site.register(Mensaje),
admin.site.register(Planta_pedido),
admin.site.register(Ejecutivo),
admin.site.register(MensajeAnonimo),
admin.site.register(RespuestaMensajeAnonimo),






